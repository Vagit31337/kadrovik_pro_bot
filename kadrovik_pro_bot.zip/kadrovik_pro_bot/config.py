# config.py
# Конфигурация Telegram бота

# Токен бота (получить у @BotFather)
BOT_TOKEN = "7969361974:AAGTPOZbPNHeszvOreiB84IJwpDqEhpvbdc"

# ID администратора (узнать у @userinfobot)
ADMIN_ID = 999077284

# Платежные реквизиты
PAYMENT_DETAILS = {
    "sberbank": "0000 1111 2222 3333",
    "tinkoff": "4444 5555 6666 7777",
    "qiwi": "+79998887766"
}

# Настройки базы данных (пример для будущего расширения)
# DATABASE = {
#     "host": "localhost",
#     "user": "admin",
#     "password": "secret",
#     "database": "telegram_bot"
# }